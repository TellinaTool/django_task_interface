## Tips
* `Tab` will complete file names
* `Control + k` will cut
* `Control + y` will paste
* `Control + n / p` will cycle through history
* `Control + c` will cancel current
* `$ history | more` will let you view your previous commands

## Common Issues

* `control + z` by accident? Use `fg` to fix.
    * Zombing / Backgrounding tasks
* Control C to cancel
* Strange ssh messages when ssl cert changes - just the one line
* Messaging and how to block