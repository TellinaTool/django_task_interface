## Schedule Spring 2014*

* 01.16 - Intro to command line interface
* 01.23 - Text Editors & CLI continued
* 01.30 - Compilation process & GDB
* 02.06 - Files management, Transferring, Intro Pipes
* 02.13 - Pipes, Redirection, Filters
* 02.20 - Shell Scripting (Project Assigned)
* 02.27 - Introduction to Git
* 03.06 - More debugging with GDB
* 03.13 - __Midterm__
* 03.20 - __No Class__ (Spring Break)
* 03.27 - Make Files & Git Review (Project Assigned)
* 04.03 - Regular Expressions
* 04.10 - Server Setup Basics
* 04.17 - TBD
* 04.24 - TBD
* 05.01 - __Final__
* 05.08 - No Class
<hr/>

###### *Subject to change depending on overall schedule.
