class-website-template
======================

This is the source code for the SSU CS210 Website.

I intend to make this more generic so it can be used by any class by making changes to a config file.

An offline compile process would ideally convert a yaml config files into navigation.json and create the entire site.
